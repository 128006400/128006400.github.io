const quotes = [
  "Typing is the skill of the future. Practice daily!",
  "Practice makes perfect, keep typing every day.",
  "Accuracy is more important than speed at first.",
  "Fast fingers and focused mind win the race.",
  "Consistent practice improves your typing speed."
];

const quoteElement = document.getElementById("quote");
const input = document.getElementById("input");
const result = document.getElementById("result");
const restartBtn = document.getElementById("restart");
const timerDisplay = document.getElementById("timer");

let startTime = null;
let countdown;
let timeLeft = 60;
let currentQuote = "";

function getRandomQuote() {
  return quotes[Math.floor(Math.random() * quotes.length)];
}

function startTimer() {
  timeLeft = 60;
  timerDisplay.innerText = `⏱️ Time Left: ${timeLeft}s`;
  countdown = setInterval(() => {
    timeLeft--;
    timerDisplay.innerText = `⏱️ Time Left: ${timeLeft}s`;
    if (timeLeft <= 0) {
      clearInterval(countdown);
      input.disabled = true;
      result.innerText = "⏰ Time's up! Try again.";
    }
  }, 1000);
}

function startTyping() {
  currentQuote = getRandomQuote();
  quoteElement.innerText = currentQuote;
  input.value = "";
  result.innerText = "";
  input.disabled = false;
  input.focus();
  startTime = null;
  clearInterval(countdown);
  startTimer();
}

input.addEventListener("input", () => {
  if (!startTime) {
    startTime = new Date();
  }

  const typedText = input.value;
  if (typedText === currentQuote) {
    const endTime = new Date();
    const timeTaken = (endTime - startTime) / 1000;
    const words = currentQuote.split(" ").length;
    const wpm = Math.round((words / timeTaken) * 60);

    result.innerText = `🎉 Perfect! Time: ${timeTaken.toFixed(2)}s | WPM: ${wpm}`;
    clearInterval(countdown);
    input.disabled = true;
  }
});

restartBtn.addEventListener("click", startTyping);

window.onload = startTyping;
